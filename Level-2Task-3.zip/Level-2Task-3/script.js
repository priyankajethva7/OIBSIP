var taskInput = document.getElementById('taskInput');
var addButton = document.getElementById('addButton');
var taskList = document.getElementById('taskList');

addButton.addEventListener('click', function() {
  var taskText = taskInput.value;

  if (taskText) {
    var taskItem = document.createElement('li');
    taskItem.classList.add('task');

    var taskImage = document.createElement('img');
    taskImage.classList.add('task-image');
    taskImage.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEXz9fQYGBgAAAD5+/r2+Pf7/fwWFhYTExMQEBANDQ0ICAjp6+rw8vHs7u3k5uUFBQXR09Lc3t3Z29q8vr3ExsXLzcxjZGMvLy85OTlCQkKytLO7vbxPT0+en58iIiInJyd7fHt0dHSnqKdKS0uOj45UVVSEhYSWl5YyMjJra2t1d3akpaVcXFw7PDuRkpEdHh5ZHfN2AAAKIElEQVR4nO2d53riOhCGYSS5ggvNdAKEtpBw/3e3kgVYBheFFDt55v13guH4Y0bTJLONBoIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgSH0gjDFCCOVUfSvfAm2NX7bb99mq2w/CNtf693QO4MZ5OD3sup0Gl1n1XX0dtA/NK4Zh2j6AFZ1m/b+jknYThVehpg1gDFbeHxHZGoJtWZZpGoahqDQcgNHMI6Tq+/s81HuZrkejYTQ3+Ur0bTPRaQGcxu3fb0jKBKTldfrd2b/NnhvPvqrklly8hr9JI6X5aU+8wFOj25lsN9yc5kWkCf4h+C0aSSPojkXao6zgjil/1Zu8DG8iDYBB/zdoJK3jyBdZz5m/HXqs8FqustXfRuBIdzV8GARF30odoGy1AMuQcZKHkGWxRPEO0ugdrobkGl/c0rdUCfHWt5UlPe9F434pc3dNsK6+eqyxGUkXnLu0Dj2d2+VrcjW8aVx36poeySplwBhno3m3hI7fLm+3YdeopRm5QONeYNOwO7o3SxrHSH6CAZuwhmYkkwyBzSbs9CMHcbcXN/fP49oFHNoxH1w0drn1/YVE9sGZH0KCjfyeTNjWrYOkaydLIPe4IHWndLLbzcaTXhC3wY8fQ49gXzy1XSuJbPbQHl3d9FX1N3q49sH24rTruo8qSTiUZoSoVouxnbkIBdaolVxGg8t1hhH3hzB87dM7kZRtZVC1nX59JPKbyhHIbdFPFNDe3XW87plvg0ZaCZs0Hflity4SqevkmZAr3Cq32eadsC0a4eR13mFM7/pD1hmBfKkuIZXkrkJxm5HqpuFyOl0PF3Ftfgu+Nuxnrmou6p7qJZGOrHyFzVTlxivtRsv1wmC8HSySLtiE6Kj6Km38q5PEW/zIUfjysJriNpi2g90JLuUo1/LWU2tusr1ILGnBfgSyK3BSUbnlvZGHUe84Al9+PxYc2sp3wd6lRL8GhTjb2EUKmzDJz93clgHPkZd69NxVDMYlij9bZ6/q1E+9RWbBdsM5FDoaZd6LcyvWlLaCvcZ/dUZVVzcly1DYpuwTWOdwWY+wcZX0KcMNLCtWSMaFy1Dc4rhsKVHSvRVr6robSImzapdiUUFzcdNTeTwkrWuxdu7frqbtkRM7QbX1G1v6JQoNRydY3Io1M0kQNLSEbGvf/k4FpXc2yG6cVDddpW2QPTAmoSzWuMTb5URWsvCvyqyoodDeqDdIWr1eEJLHBpG2ZLFmNZO1eFkD0KvQTzUUmnM3uZ5MZIc4Pxw7d60T5dFTxBt7nrg1iXtr02o1KoMdShUajtLpty8zNdMB2L+HaX8lL7HJ/GT4QcO4cdEavX4T7KUslopgeNORSp+8dbrbkSFL6ZWJIHKE5uM45CcpKUsfbNhY+Mo2qeHDMkwNOuRaVHPoRjiJc6pMIZ2UKjQXqVHGWi5E62rg80pxVdoeijLXtG9LkQbCTw2YVBVsSqu2h3FUy/O8/mo7uu7ImHBoKRI7tvizn5QJMp7a66qCTWnl3YTpw3t4g0ga4W4hNRowUmoCWQYaiZ9Sd242dYq/74JNS7qnU86d8VwxvkzynXmoSIyjjVLIyGFlamz3o5QUpjAo+OoJ3cn1aCtt4MUr1B2BqFIjZpyWSQks3kliQRS/3Rkma5HFuzzm4iaarOKV+ODtPwT1zgXDRDWIZL/9MliDQ2IhGjs+7JK/nGMj9ivKGAVjjHKBIrYOZGhZJT1FLzZidCv25Er0lxW5qfShbBctFyhS4FQ0YOY5iTYyeik9SbxvYIBbjRGpl5MRnanebi4PLSLcQGIiubaVhSdrQzhWZMScfGFAqPmVy/1VtfZkMpx2ksImThjDiurvnFGNM9C+HxanQMWIst6G18Sq69jMut/ZV0Nztri1fYqGYsBvKMWoG8eafdInxrHmAx/5tWQnff8Ds4eHdcZOdspmNBSSrVFFbir/94/rUH9cLet3O2mRZIBWQ4vISfpL+6shmaMM2H7AiHsrTgfX/+YBupmal8s+tLrKrZ/lpoahb0QS78SoW3F7U/TOSRUQW9kvPyv3TdDNJ40oM6Ay3ibxTF/J8e7QTMWeH0bWWQ9G1D8TxYNnM7Unfgme3SRFipGXYWl/4ldDB1mj78LWKQ0TX5EzSHqoeBisFG6XFFmwV/e98JWYGU61pytEVDH2VOkSZc6/W4jpiciPQg5ZwcYa6hbLZGiJfJdc7TaNVDCVjbGtsc3zTdCOlVnYbDWNGH9DapPYFpFF3RCIC7fqZhl5hY2he+6HhhFApCT0VizoLVEoQ828qpwv2rx51tDNPGv6KW13u6kNbVHEmFGikLxCtcPvvBYDNrorJ72HQUVlai4UheP7ouDHYZlp/9nwF6d8f6qsw/v88fNkF+AiZTwjkYZ7AFNJ8HK8D+9VbnnnnDM17eCZu6LuZKIWtjQU+aPKfTZxE9NMP7X3zwXAu91wT4Sy6mrvGJ4UMzcx/PVXTMlaYvRdcgDp28mbLMJGZ65YhmioPjD9+R5oZvEm9mc+f/qe1EOhu8+egMPm0xLjOYDO+aPvheTtmILmfDgftgTDVCaMVcGyng+SEj8bbtons7ms8NzJldzTGTD65DMUlHTq8RQGneZIdKLCM3jxE8QlH131cVoJdaOc/TbLyj+aTkkwXk06v+MnCPIe9IqPAecoYMHGEY8LrWfhbxBJMkdvAgOm7SxPZRP5yLN4fnh99FgtllsRbJx7ysbJesKAKIOsWOTKJTW3JDvmSuSeem9GEvhpt7YBBmP3/rGvesF2uRINeOulz+v1zYfHbgwH/MPYq7Ml5U5ENjZslSedSM/IfK6Ii2weJl59n1+PJ0e5ZozGV+uQnpX74JThw+Iwqe3vEBRJ5KtxE/9IBGXdx8fcUxdykVVt/ZZC3gvOLXIfXIaMua/FAuW3Ud3p0hLIrOhopgEQ7aH08Kag2tP6RbCMX1pQNaaeJy26sMpBcDFs7BQ9f6lNDdrCPFivWXz+VA9be3L+85BOVHoSvBzrrWodBVA3r1/8AMpp0xpCW/+0AmYRhlnZBr4WPGuUJr0ShX5tg6mE9c5lD/H9coUN4k0/5amGUW8vbYgZ0it8IjOaUaVPWerBJovnYypUvCGjB/EOzwYco7Jz+h+D0pX9XMCpfrdCF+Kdngk4BtQ+ztygbKzXL6WA999iQgFpLz8aVPUPrNQDyib7D5nR0T4cVxuIu3X0I44TVXfQ62koCwag2TbCWw1+ouYJKO1NdTQacKpz21QI17gpDas27GqyZfgUlARLgMxjqdJ+Nqw7vyuKPkBZazUCsDMmboYJsO7Vd6KvD2Hh6jQHcKzkhwji3xyMXvp/QZ+AEub2doO38+3fT7D3m/de66/ok3CVrTCYzF63r7txv5Pxq5h/gfh3CMQ/ZfKboyeCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIH+I/7stgmCGU3izAAAAAElFTkSuQmCC'; // Replace with your own image
    taskItem.appendChild(taskImage);

    var taskTextElement = document.createElement('span');
    taskTextElement.classList.add('task-text');
    taskTextElement.textContent = taskText;
    taskItem.appendChild(taskTextElement);

    var taskDateElement = document.createElement('span');
    taskDateElement.classList.add('task-date');
    taskDateElement.textContent = getCurrentDateTime();
    taskItem.appendChild(taskDateElement);

    var taskActions = document.createElement('div');
    taskActions.classList.add('task-actions');

    var editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.addEventListener('click', function() {
      var newTaskText = prompt('Edit the task:', taskText);
      if (newTaskText) {
        taskTextElement.textContent = newTaskText;
        taskDateElement.textContent = getCurrentDateTime();
      }
    });
    taskActions.appendChild(editButton);

    var deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', function() {
      taskItem.remove();
    });
    taskActions.appendChild(deleteButton);

    taskItem.appendChild(taskActions);

    taskList.appendChild(taskItem);

    taskInput.value = '';
  }
});

function getCurrentDateTime() {
  var currentDateTime = new Date();
  var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric' };
  return currentDateTime.toLocaleDateString(undefined, options);
}
